
class PropsFunctions():
    def __init__(self) -> None:
        self.METHOD_LIST = {}
